package com.example.android_project_24_retrofit.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.android_project_24_retrofit.R;
import com.example.android_project_24_retrofit.models.Books;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.MyViewHolder> {

    Context context;
    List<Books> data;

    public BookAdapter(Context context, List<Books> data) {
        this.context = context;
        this.data = data;
    }


    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_books, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MyViewHolder myViewHolder, int i) {
        myViewHolder.txt_name_book.setText(data.get(i).getName());
        myViewHolder.txt_author_book.setText(data.get(i).getDescription());
        myViewHolder.txt_price.setText(data.get(i).getPrice());

        Picasso.get().load(data.get(i).getImage()).into(myViewHolder.img_books);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txt_name_book, txt_author_book, txt_price;
        ImageView img_books;

        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            txt_name_book = itemView.findViewById(R.id.txt_name_book);
            txt_author_book = itemView.findViewById(R.id.txt_author_book);
            txt_price = itemView.findViewById(R.id.txt_price);
            img_books = itemView.findViewById(R.id.img_books);
        }
    }
}
