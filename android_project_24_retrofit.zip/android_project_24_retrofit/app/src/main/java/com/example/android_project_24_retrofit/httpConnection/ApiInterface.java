package com.example.android_project_24_retrofit.httpConnection;

import com.example.android_project_24_retrofit.models.Books;

import java.util.List;

import retrofit2.http.GET;
import retrofit2.Call;

public interface ApiInterface {

    @GET("products")
    Call<List<Books>> getData();
}
